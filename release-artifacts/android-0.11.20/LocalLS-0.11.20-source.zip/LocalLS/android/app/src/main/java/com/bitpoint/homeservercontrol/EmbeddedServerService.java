package com.bitpoint.homeservercontrol;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.File;
import java.security.KeyPair;
import java.util.concurrent.*;

/** Explicit, foreground-only lifetime. No auto-start after reboot or process death. */
public class EmbeddedServerService extends Service {
    static final String PREFS="embedded_sftp_settings", STOP="localls.embedded.STOP", AUTHORIZE="localls.embedded.AUTHORIZE_FIRST";
    static volatile boolean running,starting,waitingForClient;
    static volatile String status="Сервер выключен",fingerprint="";
    static volatile int boundPort;
    static volatile long launchRequested;
    static volatile String lastStage="IDLE";
    static volatile String diagnostic="";
    static void failure(String stage,Throwable error) {
        lastStage=stage;
        diagnostic="LocalLS Android / SDK "+Build.VERSION.SDK_INT+"\n"+ServerStartupFailure.report(stage,error);
        status=ServerStartupFailure.hint(stage,error)+"\nКод: "+stage+" / "+error.getClass().getSimpleName();
    }
    private static final Semaphore LISTENER_SLOT=new Semaphore(1,true);
    private final Object lifecycle=new Object();
    private boolean ownsListener;
    private final Handler startupWatchdog=new Handler(Looper.getMainLooper());
    private final Runnable renewPower=new Runnable(){public void run(){synchronized(lifecycle){if(!destroyed && wake!=null){wake.acquire(15*60*1000L);startupWatchdog.postDelayed(this,10*60*1000L);}}}};
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private EmbeddedSftpServer server;
    private volatile AutoReceive autoReceive;
    static final String RETRY_SAVE="localls.embedded.RETRY_SAVE";
    private volatile boolean destroyed;
    private PowerManager.WakeLock wake;
    static File share(Context c) { return new File(c.getFilesDir(),"sftp-share"); }
    static void start(Context c) {
        Intent i=new Intent(c,EmbeddedServerService.class);
        launchRequested=SystemClock.elapsedRealtime();lastStage="DISPATCH";status="Запрашиваем запуск службы…";
        try {if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
        catch(RuntimeException e) {launchRequested=0;failure("FOREGROUND",e);throw e;}
    }
    static void authorizeFirstClient(Context context,String publicKey) {
        if(!running || !waitingForClient)throw new IllegalStateException("Сначала запусти сервер в ожидании телефона");
        context.startService(new Intent(context,EmbeddedServerService.class).setAction(AUTHORIZE).putExtra("public_key",publicKey));
    }
    private static String runningStatus() {
        return waitingForClient?"Сервер готов, порт "+boundPort+". Ожидает телефон 2. Вход пока закрыт.":
                "Сервер работает, порт "+boundPort+". Разрешён вход по добавленному ключу.";
    }
    private void approve(Intent intent,int id) {
        if(destroyed || !running || !waitingForClient) {if(!running && !starting)stopSelf(id);return;}
        final String text=intent.getStringExtra("public_key");
        worker.execute(() -> {
            if(destroyed || !running || !waitingForClient)return;
            try {
                String normalized=EmbeddedSftpServer.normalizeAuthorizedKey(text);
                server.authorizeFirstClient(EmbeddedSftpServer.authorizedKey(normalized));
                if(!getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("allowed_key",normalized).commit())
                    throw new java.io.IOException("Не удалось сохранить разрешение");
                synchronized(lifecycle){if(destroyed)return;waitingForClient=false;lastStage="RUNNING";status=runningStatus();}
            } catch(Exception | LinkageError error) {
                synchronized(lifecycle){if(!destroyed){failure("KEY",error);stopSelf();}}
            }
        });
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if(intent!=null && AUTHORIZE.equals(intent.getAction())) {approve(intent,id);return START_NOT_STICKY;}
        if(intent!=null && RETRY_SAVE.equals(intent.getAction())){if(autoReceive!=null)autoReceive.retry();else stopSelf(id);return START_NOT_STICKY;}
        launchRequested=0;lastStage="SERVICE_RECEIVED";
        if(intent!=null && STOP.equals(intent.getAction())) { stopSelf();return START_NOT_STICKY; }
        if(Build.VERSION.SDK_INT<26) { status="Встроенный сервер требует Android 8 или новее";stopSelf();return START_NOT_STICKY; }
        if(running || starting) return START_NOT_STICKY;
        try {
        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel("embedded_sftp","Файловый сервер LocalLS",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,81,new Intent(this,EmbeddedServerActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,82,new Intent(this,EmbeddedServerService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        startForeground(2210,new Notification.Builder(this,"embedded_sftp")
                .setSmallIcon(com.bitpoint.homeservercontrol.ui.R.drawable.ic_cloud_notification).setContentTitle("SFTP-сервер LocalLS")
                .setContentText("Доступ по ключу к папке LocalLS. Нажми, чтобы открыть управление.")
                .setContentIntent(open).setOngoing(true).addAction(0,"Остановить",stop).build());
        } catch(RuntimeException e) {failure("FOREGROUND",e);stopSelf();return START_NOT_STICKY;}
        starting=true;diagnostic="";lastStage="SERVICE_STARTING";status="Запуск сервера…";
        SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
        p.edit().putBoolean("server_role",true).apply();
        final String publicKey=p.getString("allowed_key", ""), user=p.getString("user","localls");
        final int port=p.getInt("port",8022);
        startupWatchdog.postDelayed(() -> {
            if(!destroyed && starting && !running) {failure("TIMEOUT",new TimeoutException());stopSelf();}
        },45000);
        worker.execute(() -> {
            String stage="KEY";boolean keep=false;
            try {
                java.security.PublicKey allowed=publicKey.trim().isEmpty()?null:EmbeddedSftpServer.authorizedKey(publicKey);
                stage="IDENTITY";
                KeyPair identity=EmbeddedServerIdentity.loadOrCreate(this);
                if(destroyed)return;
                stage="NETWORK";
                // A preceding service may still be closing its listener after onDestroy returned.
                if(!LISTENER_SLOT.tryAcquire(30,TimeUnit.SECONDS))throw new TimeoutException("Previous server is still stopping");
                ownsListener=true;if(destroyed)return;
                EmbeddedSftpServer next=new EmbeddedSftpServer();server=next;autoReceive=new AutoReceive(this);
                if(destroyed)return;
                next.onReceived(autoReceive::received);
                int openedPort=allowed==null?next.startWaiting("0.0.0.0",port,user,identity,share(this).toPath()):
                        next.start("0.0.0.0",port,user,allowed,identity,share(this).toPath());
                synchronized(lifecycle){
                    if(destroyed)return;
                    stage="POWER";
                    PowerManager pm=getSystemService(PowerManager.class);wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"LocalLS:EmbeddedSftp");wake.setReferenceCounted(false);wake.acquire(15*60*1000L);startupWatchdog.post(renewPower);
                    boundPort=openedPort;waitingForClient=allowed==null;fingerprint=EmbeddedSftpServer.fingerprint(identity);
                    lastStage=waitingForClient?"WAITING_CLIENT":"RUNNING";running=true;status=runningStatus();keep=true;
                }
            } catch(Exception | LinkageError e) {
                synchronized(lifecycle){if(!destroyed){running=false;failure(stage,e);stopSelf();}}
            } finally {
                synchronized(lifecycle){if(!destroyed)starting=false;}
                if(!keep || destroyed)closeResources();
            }
        });
        return START_NOT_STICKY;
    }
    @Override public void onTimeout(int id,int type) { status="Сервер остановлен: Android ограничил время фоновой службы. Запусти его снова.";stopSelf(); }
    private void closeResources(){
        try{if(server!=null)server.close();}catch(Exception ignored){}finally{server=null;}
        try{if(autoReceive!=null)autoReceive.close();}catch(RuntimeException ignored){}finally{autoReceive=null;}
        synchronized(lifecycle){startupWatchdog.removeCallbacks(renewPower);try{if(wake!=null && wake.isHeld())wake.release();}catch(RuntimeException ignored){}finally{wake=null;}}
        if(ownsListener){ownsListener=false;LISTENER_SLOT.release();}
    }
    @Override public void onDestroy() {
        synchronized(lifecycle){
            destroyed=true;if(autoReceive!=null)autoReceive.close();startupWatchdog.removeCallbacksAndMessages(null);running=false;starting=false;waitingForClient=false;
            if(status.startsWith("Сервер работает") || status.startsWith("Сервер готов") || status.startsWith("Запуск"))status="Сервер выключен";
        }
        // The worker also sees resources whose constructors finished after destruction began.
        worker.execute(this::closeResources);worker.shutdown();stopForeground(true);super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
